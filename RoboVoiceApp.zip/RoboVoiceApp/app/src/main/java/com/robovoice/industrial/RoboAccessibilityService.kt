package com.robovoice.industrial

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Used only for global actions (lock screen, screenshot). Reads no screen content. */
class RoboAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RoboAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
}
