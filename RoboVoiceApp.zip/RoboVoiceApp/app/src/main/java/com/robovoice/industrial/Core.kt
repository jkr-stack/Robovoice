package com.robovoice.industrial

import android.os.Handler
import android.os.Looper
import java.util.UUID

/** MUST match the UUIDs and device name in your ESP32 firmware exactly. */
object Cfg {
    val SERVICE_UUID: UUID = UUID.fromString("c8b1a2d4-6e5f-4a3b-8c9d-0e1f2a3b4c5d")
    val CHAR_UUID: UUID = UUID.fromString("d9c2b3e5-7f6a-5b4c-9d0e-1f2a3b4c5d6e")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    const val DEVICE_NAME = "RoboVoice"
    const val PREFS = "robovoice"
    const val KEY_MAINT = "maint_number"
    const val DEFAULT_MAINT = "+910000000000"
}

/** Simple shared status text shown on the main screen. */
object Status {
    @Volatile
    var text: String = "Stopped"
    var listener: ((String) -> Unit)? = null

    fun set(s: String) {
        text = s
        Handler(Looper.getMainLooper()).post { listener?.invoke(s) }
    }
}
