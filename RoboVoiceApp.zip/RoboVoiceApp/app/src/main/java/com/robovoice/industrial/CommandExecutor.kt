package com.robovoice.industrial

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationCompat

/** Maps a command ID received over BLE to a phone action. */
object CommandExecutor {

    private const val ALERT_CHANNEL = "robovoice_alerts"

    fun run(ctx: Context, cmd: String) {
        when (cmd) {
            "CMD_01" -> launchPackage(ctx, "com.google.android.youtube", "YouTube")
            "CMD_02" -> launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Camera")
            "CMD_03" -> volume(ctx, AudioManager.ADJUST_RAISE)
            "CMD_04" -> volume(ctx, AudioManager.ADJUST_LOWER)
            "CMD_05" -> globalAction(ctx, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "CMD_06" -> globalAction(ctx, AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            "CMD_CALL_MAINT" -> callMaintenance(ctx)
            "CMD_EMERGENCY" -> alert(ctx, 99, "EMERGENCY", "Emergency button pressed on the terminal", null)
            else -> { /* unknown ID: ignore */ }
        }
    }

    private fun launchPackage(ctx: Context, pkg: String, label: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) alert(ctx, 10, "$label not installed", "Install $label to use this command", null)
        else launch(ctx, i, label)
    }

    /**
     * Android 10+ blocks background apps from starting activities.
     * With "Display over other apps" granted, startActivity works from the service.
     * Otherwise we fall back to a full-screen / tap-to-open notification.
     */
    private fun launch(ctx: Context, intent: Intent, label: String) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Settings.canDrawOverlays(ctx)) {
            try {
                ctx.startActivity(intent)
                return
            } catch (_: Exception) { }
        }
        alert(ctx, 11, "Open $label", "Tap to open $label", intent)
    }

    private fun volume(ctx: Context, dir: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun globalAction(ctx: Context, action: Int) {
        val svc = RoboAccessibilityService.instance
        if (svc == null || Build.VERSION.SDK_INT < 28) {
            alert(ctx, 12, "Accessibility service off", "Enable the RoboVoice accessibility service in Settings", null)
        } else {
            svc.performGlobalAction(action)
        }
    }

    private fun callMaintenance(ctx: Context) {
        val number = ctx.getSharedPreferences(Cfg.PREFS, Context.MODE_PRIVATE)
            .getString(Cfg.KEY_MAINT, Cfg.DEFAULT_MAINT) ?: Cfg.DEFAULT_MAINT
        // ACTION_DIAL needs no permission; the user taps the call button.
        launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), "Maintenance dialer")
    }

    private fun alert(ctx: Context, id: Int, title: String, text: String, intent: Intent?) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(ALERT_CHANNEL, "RoboVoice alerts", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val b = NotificationCompat.Builder(ctx, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
        if (intent != null) {
            val pi = PendingIntent.getActivity(
                ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.setContentIntent(pi).setFullScreenIntent(pi, true)
        }
        nm.notify(id, b.build())
    }
}
