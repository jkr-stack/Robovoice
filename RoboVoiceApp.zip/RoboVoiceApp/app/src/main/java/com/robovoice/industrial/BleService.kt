package com.robovoice.industrial

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.*
import android.bluetooth.le.*
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Foreground service: scans for the ESP32, connects, subscribes, and auto-reconnects. */
@SuppressLint("MissingPermission")
class BleService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var scanning = false
    private var running = false

    private val adapter: BluetoothAdapter?
        get() = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "RoboVoice connection", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg("Starting…")
        if (!hasBlePermissions()) {
            setState("Missing Bluetooth permission – open the app and grant permissions")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            startScan()
        }
        return START_STICKY
    }

    // ---------- foreground notification ----------

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("RoboVoice Industrial")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun startFg(text: String) {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(text), type)
    }

    private fun setState(text: String) {
        Status.set(text)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun hasBlePermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    // ---------- scanning ----------

    private fun startScan() {
        if (!running || scanning) return
        val a = adapter
        if (a == null || !a.isEnabled) {
            setState("Bluetooth is off – turn it on")
            main.postDelayed({ startScan() }, 5000)
            return
        }
        val scanner = a.bluetoothLeScanner
        if (scanner == null) {
            main.postDelayed({ startScan() }, 5000)
            return
        }
        val filter = ScanFilter.Builder().setDeviceName(Cfg.DEVICE_NAME).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanning = true
        setState("Scanning for ${Cfg.DEVICE_NAME}…")
        scanner.startScan(listOf(filter), settings, scanCallback)
    }

    private fun stopScan() {
        if (scanning) {
            adapter?.bluetoothLeScanner?.stopScan(scanCallback)
            scanning = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            stopScan()
            connect(result.device)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            main.postDelayed({ startScan() }, 5000)
        }
    }

    // ---------- GATT ----------

    private fun connect(device: BluetoothDevice) {
        setState("Connecting…")
        gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {

        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setState("Connected, discovering services…")
                g.discoverServices()
            } else {
                g.close()
                gatt = null
                if (running) {
                    setState("Disconnected – reconnecting…")
                    main.postDelayed({ startScan() }, 3000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val ch = g.getService(Cfg.SERVICE_UUID)?.getCharacteristic(Cfg.CHAR_UUID)
            if (ch == null) {
                setState("Service not found – check UUIDs match the ESP32")
                return
            }
            g.setCharacteristicNotification(ch, true)
            val d = ch.getDescriptor(Cfg.CCCD) ?: return
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(d, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            } else {
                @Suppress("DEPRECATION")
                d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                g.writeDescriptor(d)
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            setState("Listening – connected to ${Cfg.DEVICE_NAME}")
        }

        // Android 13+
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic, value: ByteArray) {
            handleCommand(String(value))
        }

        // Android 12 and below
        @Deprecated("Deprecated in API 33")
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            if (Build.VERSION.SDK_INT < 33) {
                @Suppress("DEPRECATION")
                handleCommand(String(ch.value ?: return))
            }
        }
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.trim().trim('\u0000')
        if (cmd.isEmpty()) return
        main.post {
            Status.set("Last command: $cmd")
            CommandExecutor.run(applicationContext, cmd)
        }
    }

    // ---------- lifecycle ----------

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        stopScan()
        gatt?.close()
        gatt = null
        Status.set("Stopped")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "robovoice_conn"
        private const val NOTIF_ID = 1
    }
}
