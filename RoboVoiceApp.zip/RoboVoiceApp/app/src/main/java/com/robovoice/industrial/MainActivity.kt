package com.robovoice.industrial

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String) = root.addView(TextView(this).apply { text = t; textSize = 16f; setPadding(0, pad, 0, 0) })
        fun button(t: String, onClick: () -> Unit) = root.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { onClick() }
        })

        statusView = TextView(this).apply { textSize = 18f; text = "Status: ${Status.text}" }
        root.addView(statusView)

        label("One-time setup")
        button("1. Grant permissions (Bluetooth, notifications)") { requestPerms() }
        button("2. Allow background running (battery)") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        button("3. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("4. Enable accessibility service (lock/screenshot)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        label("Maintenance phone number")
        val prefs = getSharedPreferences(Cfg.PREFS, MODE_PRIVATE)
        val numberBox = EditText(this).apply { setText(prefs.getString(Cfg.KEY_MAINT, Cfg.DEFAULT_MAINT)) }
        root.addView(numberBox)
        button("Save number") {
            prefs.edit().putString(Cfg.KEY_MAINT, numberBox.text.toString().trim()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        label("Run")
        button("Start listening") {
            ContextCompat.startForegroundService(this, Intent(this, BleService::class.java))
        }
        button("Stop listening") { stopService(Intent(this, BleService::class.java)) }

        label("Test actions without the ESP32")
        listOf("CMD_01", "CMD_02", "CMD_03", "CMD_04", "CMD_05", "CMD_06", "CMD_CALL_MAINT", "CMD_EMERGENCY")
            .forEach { id -> button("Test $id") { CommandExecutor.run(applicationContext, id) } }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        statusView.text = "Status: ${Status.text}"
        Status.listener = { statusView.text = "Status: $it" }
    }

    override fun onPause() {
        Status.listener = null
        super.onPause()
    }

    private fun requestPerms() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            perms += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }
}
