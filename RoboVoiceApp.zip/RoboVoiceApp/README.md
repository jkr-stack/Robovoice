# RoboVoice Android companion app

Receives command IDs from the ESP32 over BLE and runs phone actions.

## Before building
1. Open `app/src/main/java/com/robovoice/industrial/Core.kt` and make `SERVICE_UUID`, `CHAR_UUID` and `DEVICE_NAME` match your ESP32 firmware exactly.
2. Command map is in `CommandExecutor.kt` (CMD_01 YouTube, 02 Camera, 03 Vol up, 04 Vol down, 05 Lock, 06 Screenshot, CALL_MAINT, EMERGENCY).

## Build the APK (pick one)
**A. GitHub Actions (no PC tooling):** push this folder to a new GitHub repo. Open Actions > Build APK > Run workflow. Download the `RoboVoice-APK` artifact, unzip, install `app-debug.apk`.

**B. Android Studio:** File > Open this folder, let Gradle sync, then Build > Build APK(s). APK is in `app/build/outputs/apk/debug/`.

## First run on the phone
Install the APK (allow unknown apps), open it, then tap setup buttons 1 to 4 in order, save the maintenance number, and tap Start listening. Use the Test buttons to check each action before connecting the ESP32.

## Notes
- The ESP32 must advertise the name `RoboVoice`.
- Debug APK is fine for demos. No signing or paid account needed.
